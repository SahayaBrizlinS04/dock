from fastapi import FastAPI, BackgroundTasks
from icon_extractor import extract_icons_from_pdf
from index_chromadb import index_images
from Query_chromadb import main

app = FastAPI()
 
def run_full_processing():
    extract_icons_from_pdf("RMC4916_0736003737_POUCH_LABEL.pdf")
    extract_icons_from_pdf("RMC4916_0738002356_Carton_LABEL.pdf")
    index_folder = r"C:\Users\kumar\Downloads\Image_comparison\Labelling_icons_by_pdf"
    index_images(index_folder)
    main()
    

@app.get("/")
async def root():
    return {"message": "Welcome to Symbol Extraction API"}
 
@app.get("/process-all/")
async def process_all(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_full_processing)
    return {"status": "Processing started in background"}