import fitz  # PyMuPDF
 
import os
 
import json
 
def cluster_text_blocks_to_rows(text_blocks, tolerance=10):
 
    rows = []
 
    sorted_blocks = sorted(text_blocks, key=lambda b: b[1])  # sort by y0
 
    current_row = []
 
    last_y = None
 
    for block in sorted_blocks:
 
        y0 = block[1]
 
        if last_y is None or abs(y0 - last_y) <= tolerance:
 
            current_row.append(block)
 
            last_y = y0 if last_y is None else (last_y + y0) / 2
 
        else:
 
            rows.append(current_row)
 
            current_row = [block]
 
            last_y = y0
 
    if current_row:
 
        rows.append(current_row)
 
    return rows
 
def extract_vector_shapes_and_labels(pdf_path, output_folder="IFU_symbols", page_number=None):
 
    os.makedirs(output_folder, exist_ok=True)
 
    doc = fitz.open(pdf_path)
 
    all_results = []
 
    if page_number is not None:
 
        pages_to_process = [page_number - 1]
 
        if pages_to_process[0] < 0 or pages_to_process[0] >= len(doc):
 
            print(f"❌ Error: Page number {page_number} is out of range.")
 
            return
 
        print(f"📄 Processing only page {page_number} of PDF: {pdf_path}")
 
    else:
 
        pages_to_process = list(range(len(doc)))
 
        print(f"📄 Processing all {len(doc)} pages of PDF: {pdf_path}")
 
    for page_index in pages_to_process:
 
        page = doc[page_index]
 
        text_blocks = page.get_text("blocks")
 
        drawings = page.get_drawings()
 
        page_folder = os.path.join(output_folder, f"page_{page_index+1}")
 
        os.makedirs(page_folder, exist_ok=True)
 
        rows = cluster_text_blocks_to_rows(text_blocks)
 
        results = []
 
        for draw_index, item in enumerate(drawings):
 
            bbox = fitz.Rect(item["rect"])
 
            w = bbox.width
 
            h = bbox.height
 
            # Log all bounding boxes (for debugging missing icons)
 
            if not (10 < w < 100 and 10 < h < 100):
 
                continue  # Skip too small/large
 
            mat = fitz.Matrix(4, 4)
 
            clip_pix = page.get_pixmap(matrix=mat, clip=bbox)
 
            image_filename = f"IFU_symbol_{page_index+1}_{draw_index+1}.png"
 
            image_path = os.path.join(page_folder, image_filename)
 
            clip_pix.save(image_path)
 
            # Try to associate nearby text (right or below)
 
            closest_text = ""
 
            min_dist = float("inf")
 
            for block in text_blocks:
 
                bx, by, bx1, by1 = block[:4]
 
                block_rect = fitz.Rect(bx, by, bx1, by1)
 
                # Right-side match
 
                if block_rect.x0 > bbox.x1:
 
                    y_dist = abs(block_rect.y0 - bbox.y0)
 
                    if y_dist < 60 and y_dist < min_dist:
 
                        closest_text = block[4].strip()
 
                        min_dist = y_dist
 
                # Below match (if right match fails)
 
                elif block_rect.y0 > bbox.y1:
 
                    x_dist = abs(block_rect.x0 - bbox.x0)
 
                    if x_dist < 40 and block_rect.y0 - bbox.y1 < 60 and block[4].strip():
 
                        if (block_rect.y0 - bbox.y1) < min_dist:
 
                            closest_text = block[4].strip()
 
                            min_dist = block_rect.y0 - bbox.y1
 
            if closest_text:
 
                results.append({
 
                    "image_file": os.path.join(f"page_{page_index+1}", image_filename),
 
                    "description": closest_text
 
                })
 
            #else:
 
                #print(f"⚠️ No text found for symbol on page {page_index+1} at bbox {bbox}")
 
        all_results.extend(results)
 
        print(f"✅ Page {page_index+1}: {len(results)} IFU icon(s) extracted.")
 
    json_path = os.path.join(output_folder, "IFU_symbols.json")
 
    with open(json_path, "w", encoding="utf-8") as f:
 
        json.dump(all_results, f, indent=4, ensure_ascii=False)
 
    print(f"\n🎉 Done! Results saved to: {json_path}")
 
# === Run ===
if __name__ == "__main__":
    extract_vector_shapes_and_labels("RMC4916_0719004306_IFU_LABEL.pdf", page_number=2)
 
 