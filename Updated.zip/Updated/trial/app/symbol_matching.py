import os
 
import json
 
import torch
 
import torchvision.transforms as transforms
 
from torchvision import models
 
from PIL import Image
 
from tqdm import tqdm
 
from sklearn.metrics.pairwise import cosine_similarity
 
def main_matching():
 
    # Settings
 
    ICONS_BASE_FOLDER = "Labelling_icons_by_pdf"
 
    VECTOR_JSON_PATH = os.path.join("IFU_symbols", "IFU_symbols.json")
 
    SIMILARITY_THRESHOLD = 0.85
 
    RETURN_MULTIPLE_MATCHES = True
 
    # Load pretrained model
 
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
 
    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
 
    model = torch.nn.Sequential(*list(model.children())[:-1])  # Remove classification layer
 
    model.eval()
 
    model.to(device)
 
    # Image transform
 
    transform = transforms.Compose([
 
        transforms.Resize((224, 224)),
 
        transforms.CenterCrop(224),
 
        transforms.ToTensor(),
 
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
 
                             std=[0.229, 0.224, 0.225])
 
    ])
 
    def extract_features(image_path):
 
        try:
 
            image = Image.open(image_path).convert("RGB")
 
            img_t = transform(image).unsqueeze(0).to(device)
 
            with torch.no_grad():
 
                features = model(img_t).squeeze().cpu().numpy()
 
            return features.reshape(1, -1)
 
        except Exception as e:
 
            print(f"Error processing {image_path}: {e}")
 
            return None
 
    # Load vector symbols
 
    print("🔍 Loading IFU symbol features from JSON...")
 
    with open(VECTOR_JSON_PATH, "r", encoding="utf-8") as f:
 
        vector_data = json.load(f)
 
    vector_features = []
 
    for entry in vector_data:
 
        desc = entry.get("description", "").strip()
 
        rel_img_path = entry.get("image_file", "")
 
        if not desc or not rel_img_path:
 
            continue
 
        full_img_path = os.path.join("IFU_symbols", rel_img_path)
 
        if not os.path.exists(full_img_path):
 
            continue
 
        feat = extract_features(full_img_path)
 
        if feat is not None:
 
            vector_features.append({
 
                "path": full_img_path,
 
                "features": feat,
 
                "description": desc
 
            })
 
    print(f"✅ {len(vector_features)} valid vector symbols loaded.\n")
 
    # Process each icon folder
 
    for pdf_folder in os.listdir(ICONS_BASE_FOLDER):
 
        folder_path = os.path.join(ICONS_BASE_FOLDER, pdf_folder)
 
        if not os.path.isdir(folder_path):
 
            continue
 
        print(f"\n📂 Matching icons in folder: {pdf_folder}")
 
        matches = []
 
        for page_folder in sorted(os.listdir(folder_path)):
 
            page_path = os.path.join(folder_path, page_folder)
 
            if not os.path.isdir(page_path):
 
                continue
 
            icon_files = [f for f in os.listdir(page_path) if f.lower().endswith(".png")]
 
            for icon_file in tqdm(icon_files, desc=f"Processing {page_folder}"):
 
                icon_path = os.path.join(page_path, icon_file)
 
                icon_feat = extract_features(icon_path)
 
                if icon_feat is None:
 
                    continue
 
                sims = [(cosine_similarity(icon_feat, v["features"])[0][0], v) for v in vector_features]
 
                sims = [s for s in sims if s[0] >= SIMILARITY_THRESHOLD]
 
                if RETURN_MULTIPLE_MATCHES:
 
                    for sim_score, match in sims:
 
                        matches.append({
 
                            "icon_file": os.path.relpath(icon_path),
 
                            "matched_symbol_file": os.path.relpath(match["path"]),
 
                            "description": match["description"].strip(),
 
                            "similarity": float(sim_score)
 
                        })
 
                else:
 
                    if sims:
 
                        sims.sort(key=lambda x: x[0], reverse=True)
 
                        top_sim, best_match = sims[0]
 
                        matches.append({
 
                            "icon_file": os.path.relpath(icon_path),
 
                            "matched_symbol_file": os.path.relpath(best_match["path"]),
 
                            "description": best_match["description"].strip(),
 
                            "similarity": float(top_sim)
 
                        })
 
        # Save results per folder
 
        result_dir = os.path.join("match_results", pdf_folder)
 
        os.makedirs(result_dir, exist_ok=True)
 
        result_json_path = os.path.join(result_dir, "matched_results.json")
 
        result_txt_path = os.path.join(result_dir, "unique_descriptions.txt")
 
        with open(result_json_path, "w", encoding="utf-8") as f:
 
            json.dump(matches, f, indent=4)
 
        unique_descriptions = set(match["description"].strip().lower() for match in matches if match["description"])
 
        with open(result_txt_path, "w", encoding="utf-8") as f:
 
            for desc in sorted(unique_descriptions):
 
                f.write(desc + "\n")
 
        print(f"✅ Matches saved for '{pdf_folder}' ({len(matches)} matches)")
 
        print(f"📁 JSON: {result_json_path}")
 
        print(f"📝 Descriptions: {result_txt_path}")
 
if __name__ == "__main__":
 
    main_matching()
 
 