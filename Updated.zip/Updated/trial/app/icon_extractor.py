import fitz  # PyMuPDF
 
import cv2
 
import numpy as np
 
import os
 
from PIL import Image
 
import imagehash
 
def extract_icons_from_pdf(
 
    pdf_path,
 
    output_folder="Labelling_icons_by_pdf",
 
    render_zoom=2.0,
 
    min_icon_size=20,
 
    max_icon_size=300,
 
    padding=10
 
):
 
    # Extract filename without extension
 
    base_filename = os.path.splitext(os.path.basename(pdf_path))[0]
 
    # Combine with the output folder
 
    output_folder = os.path.join(output_folder, base_filename)
 
    os.makedirs(output_folder, exist_ok=True)
 
    doc = fitz.open(pdf_path)
 
    seen_hashes = set()
 
    print(f"📄 Processing PDF: {pdf_path}")
 
    print(f"Total pages: {len(doc)}\n")
 
    for page_index in range(len(doc)):
 
        # Render page to image
 
        page = doc[page_index]
 
        matrix = fitz.Matrix(render_zoom, render_zoom)
 
        pix = page.get_pixmap(matrix=matrix)
 
        img_data = np.frombuffer(pix.tobytes("png"), dtype=np.uint8)
 
        image = cv2.imdecode(img_data, cv2.IMREAD_COLOR)
 
        # Convert to grayscale and threshold
 
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
 
        _, thresh = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY_INV)
 
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
 
        page_folder = os.path.join(output_folder, f"icons_page_{page_index + 1}")
 
        os.makedirs(page_folder, exist_ok=True)
 
        icon_index = 0
 
        for cnt in contours:
 
            x, y, w, h = cv2.boundingRect(cnt)
 
            if min_icon_size < w < max_icon_size and min_icon_size < h < max_icon_size:
 
                # Padding with boundary check
 
                x_pad = max(x - padding, 0)
 
                y_pad = max(y - padding, 0)
 
                x2_pad = min(x + w + padding, image.shape[1])
 
                y2_pad = min(y + h + padding, image.shape[0])
 
                cropped = image[y_pad:y2_pad, x_pad:x2_pad]
 
                # Convert to PIL and hash
 
                pil_img = Image.fromarray(cv2.cvtColor(cropped, cv2.COLOR_BGR2RGB))
 
                hash_val = imagehash.average_hash(pil_img)
 
                if hash_val in seen_hashes:
 
                    continue  # Skip duplicate
 
                seen_hashes.add(hash_val)
 
                # Save icon
 
                icon_path = os.path.join(page_folder, f"icon_{icon_index + 1}.png")
 
                pil_img.save(icon_path)
 
                icon_index += 1
 
        print(f"✅ Page {page_index + 1}: {icon_index} unique icon(s) saved.")
 
    print(f"\n🎉 Done! All icons saved in '{output_folder}'.")
 
# === Example usage ===
 
if __name__ == "__main__":
 
    extract_icons_from_pdf("RMC4916_0736003737_POUCH_LABEL.pdf")
    extract_icons_from_pdf("RMC4916_0738002356_Carton_LABEL.pdf")
 
 