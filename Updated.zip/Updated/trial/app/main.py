from fastapi import FastAPI, BackgroundTasks
from icon_extractor import extract_icons_from_pdf
from symbol_extractor import extract_vector_shapes_and_labels
from symbol_matching import main_matching
 
app = FastAPI()
 
def run_full_processing():
    extract_icons_from_pdf("RMC4916_0736003737_POUCH_LABEL.pdf")
    extract_icons_from_pdf("RMC4916_0738002356_Carton_LABEL.pdf")
    extract_vector_shapes_and_labels("RMC4916_0719004306_IFU_LABEL.pdf", page_number=None)
    main_matching()
@app.get("/")
async def root():
    return {"message": "Welcome to Symbol Extraction API"}
 
@app.get("/process-icons/")
async def process_icons():
    extract_icons_from_pdf("RMC4916_0736003737_POUCH_LABEL.pdf")
    return {"status": "Icon extraction complete"}
 
@app.get("/process-vectors/")
async def process_vectors():
    extract_vector_shapes_and_labels("RMC4916_0719004306_IFU_LABEL.pdf", page_number=None)
    return {"status": "Vector extraction complete"}
 
@app.get("/process-all/")
async def process_all(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_full_processing)
    return {"status": "Processing started in background"}